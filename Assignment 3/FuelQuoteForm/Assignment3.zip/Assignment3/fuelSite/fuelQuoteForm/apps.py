from django.apps import AppConfig


class FuelQuoteFormConfig(AppConfig):
    name = 'fuelQuoteForm'

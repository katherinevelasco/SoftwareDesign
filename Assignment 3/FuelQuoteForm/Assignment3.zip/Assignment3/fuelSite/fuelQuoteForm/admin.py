from django.contrib import admin
from fuelQuoteForm.models import userFuelForm

# Register your models here.

admin.site.register(userFuelForm)
from django.contrib import admin
from ClientProfile.models import ClientProfile

# Register your models here.

admin.site.register(ClientProfile)
from django.apps import AppConfig


class ClientprofileConfig(AppConfig):
    name = 'ClientProfile'
